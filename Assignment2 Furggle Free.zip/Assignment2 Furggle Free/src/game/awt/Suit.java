package game.awt;

public enum Suit {
	Hearts, Diamonds, Clubs, Spades;
}
