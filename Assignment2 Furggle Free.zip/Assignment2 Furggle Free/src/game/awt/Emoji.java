package game.awt;

public enum Emoji {
	Smiley, Harpsicord, Dogfish, TastyCake, BlueTuna, DoubleAardvark, SwarmpThing, Ernie, Furggle, Error
}
